# Author        : Simon Bross
# Date          : May 29, 2024
# Python version: 3.9

import pandas as pd
import os
from numpy import nan


def csv_to_df():
    """
    Reads the training data (study_ann3.csv, first annotation round)
    and converts it into a pandas dataframe. Only the first 2002
    datapoints have small talk ratings.
    @return: Pandas dataframe.
    """
    path = os.path.join("data", "study_ann_3.csv")
    data_df1 = pd.read_csv(path, skiprows=lambda x: x not in range(0, 2004))
    return data_df1


def get_x_y(with_context=False):
    """
    Extracts the raw textual data and corresponding labels from the data.
    The labels are converted into binary ones, where values ranging from
    1 to 3 are considered to pertain to class 0 (non-small-talk),
    otherwise (4-6) to class 1 (small talk). With_context determines
    whether contextual utterances are included or not.
    @param with_context: Boolean determining whether to include context or
    not.
    @return: Tuple consisting of two lists, containing the utterances and
    labels, respectively.
    """
    data_df = csv_to_df()
    # it is possible that there are no preceding/following utterances
    # available --> replace their nan values with an empty string
    if with_context:
        utterances_zipped = zip(
            data_df["preceding_utterance"].replace(nan, "").tolist(),
            data_df["annotation_item"].tolist(),
            data_df["following_utterance"].replace(nan, "").tolist()
        )
        X = [" ".join(utterances) for utterances in utterances_zipped]
    else:
        X = data_df["annotation_item"].tolist()

    y_plain = data_df["rating"].tolist()
    y_binary = [0 if rating <= 3 else 1 for rating in y_plain]
    return X, y_binary
